/*
 * Copyright (C) 2014, Broadcom Corporation
 * All Rights Reserved.
 * 
 * This is UNPUBLISHED PROPRIETARY SOURCE CODE of Broadcom Corporation;
 * the contents of this file may not be disclosed to third parties, copied
 * or duplicated in any form, in whole or in part, without the prior
 * written permission of Broadcom Corporation.
 *
 * $Id: version.h.in,v 1.2 2008-05-14 18:13:47 $
 *
*/

#ifndef _version_h_
#define _epivers_h_

#define	MOD_MAJOR_VERSION	1

#define	MOD_MINOR_VERSION	141

#define	MOD_RC_NUMBER		5

#define	MOD_INCREMENTAL_NUMBER	20

#define	MOD_BUILD_NUMBER	0

#define	MOD_VERSION		1, 141, 5, 20

#define	MOD_VERSION_NUM		0x018d0514

/* Driver Version String, ASCII, 32 chars max */
#define	MOD_VERSION_STR		"1.141.5.20"
#define	MOD_ROUTER_VERSION_STR	"@MOD_ROUTER_VERSION_STR@"

#endif /* _version_h_ */
