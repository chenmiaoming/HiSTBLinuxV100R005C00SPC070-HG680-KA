#define PLAIN_VERSION "2015.04"
#define U_BOOT_VERSION "U-Boot " PLAIN_VERSION
#define CC_VERSION_STRING "arm-histbv300-linux-gcc (gcc-4.9.2 + eglibc-2.19 (Build by czyong) Mon Mar 9 14:14:50 CST 2015) 4.9.2 20140904 (prerelease)"
#define LD_VERSION_STRING "GNU ld (gcc-4.9.2 + eglibc-2.19 (Build by czyong) Mon Mar 9 14:14:50 CST 2015) 2.24.0.20140829 Linaro 2014.09"
