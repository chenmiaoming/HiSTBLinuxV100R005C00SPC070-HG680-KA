#define U_BOOT_DATE "Nov 07 2015"
#define U_BOOT_TIME "11:30:51"
